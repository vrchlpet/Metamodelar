/*
 * Category.java
 *
 * Created on September 21, 2006, 9:00 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *
 * To understand this class, see http://platform.netbeans.org/tutorials/nbm-nodesapi3.html
 */
package org.si23.shapesample.palette;

/**
 *
 * @author Geertjan Wielenga
 */
public class Category {

    private String name;

    /** Creates a new instance of Category */
    public Category() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
