package org.si23.shapesample;

import java.awt.Image;

public class MyNode {

    private Image image;

    public MyNode(Image image) {
        this.image = image;
    }

    public Image getImage() {
        return image;
    }
}
